(function () {
  var RULES = "You build web projects from plain-language descriptions. Reply with ONE complete, self-contained HTML file (doctype first) with inline CSS and JavaScript that works when opened as a page. Rules: no external images, fonts or network requests; no localStorage or sessionStorage (keep state in memory); responsive down to mobile; polished, intentional design with real content and working interactions. Output only the code, with no explanation and no markdown fences.";
  var $ = function (id) { return document.getElementById(id); };

  var lockup = $("lockup");
  if (lockup) lockup.addEventListener("click", function () {
    var els = document.querySelectorAll(".disc,.wave-wrap,.wave,.word span");
    els.forEach(function (el) { el.style.animation = "none"; });
    void lockup.offsetWidth;
    els.forEach(function (el) { el.style.animation = ""; });
  });

  if (!$("build")) return;

  var STORE = "swell-projects-v1", projects = load(), cur = { id: null, idea: "", html: "" }, ctrl = null;

  function load() { try { return JSON.parse(localStorage.getItem(STORE)) || []; } catch (e) { return []; } }
  function persist() { try { localStorage.setItem(STORE, JSON.stringify(projects)); return true; } catch (e) { return false; } }
  function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
  function fmt(t) { return new Date(t).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" }); }
  function slug(s) { return s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "project"; }
  function clean(t) {
    t = t.trim().replace(/^```[a-z]*\s*/i, "").replace(/\s*```$/, "");
    var i = t.search(/<!doctype|<html/i);
    return i > 0 ? t.slice(i) : t;
  }
  function guessTitle(idea, html) {
    var m = /<title>([^<]{1,60})<\/title>/i.exec(html || "");
    if (m && m[1].trim()) return m[1].trim();
    var t = (idea || "").trim().replace(/\s+/g, " ").slice(0, 44);
    return t ? t.charAt(0).toUpperCase() + t.slice(1) : "Untitled project";
  }
  function download(name, text, type) {
    var a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([text], { type: type }));
    a.download = name; a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); }, 500);
  }
  function flash(btn, msg, label) {
    btn.textContent = msg;
    setTimeout(function () { btn.textContent = label; }, 2200);
  }
  async function copyText(text, btn, label) {
    try { await navigator.clipboard.writeText(text); flash(btn, "Copied", label); }
    catch (e) { flash(btn, "Copy failed", label); }
  }

  function show(html, idea, id, title) {
    cur = { id: id || null, idea: idea || "", html: html };
    $("frame").srcdoc = html;
    $("out").style.display = "block";
    $("title").value = title || guessTitle(idea, html);
    $("savemsg").textContent = "";
    $("out").scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function busy(on) {
    $("build").disabled = on; $("update").disabled = on; $("stop").hidden = !on;
    if (!on) $("status").textContent = "";
  }

  async function ask(prompt) {
    var key = $("key").value.trim();
    if (!key) throw new Error("Paste your API key first, or use the no-key option below.");
    var res;
    try {
      res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST", signal: ctrl.signal,
        headers: { "content-type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01", "anthropic-dangerous-direct-browser-access": "true" },
        body: JSON.stringify({ model: "claude-sonnet-5-5", max_tokens: 8000, messages: [{ role: "user", content: prompt }] })
      });
    } catch (e) {
      if (e.name === "AbortError") throw e;
      throw new Error("Couldn't reach Anthropic. If you're previewing this page inside Claude, download the files and open build.html from your computer or a web host, because the preview blocks requests to other sites. Otherwise check your internet connection.");
    }
    var data = {};
    try { data = await res.json(); } catch (e) {}
    if (!res.ok) {
      if (res.status === 401) throw new Error("That API key wasn't accepted. Check that you copied the whole key, which starts with sk-ant-.");
      if (res.status === 429) throw new Error("Too many requests right now. Wait a moment and try again.");
      throw new Error((data.error && data.error.message) || "The request failed (error " + res.status + ").");
    }
    return clean(data.content.map(function (b) { return b.text || ""; }).join(""));
  }

  async function run(prompt, errEl, idea, keepId, keepTitle) {
    errEl.textContent = "";
    ctrl = new AbortController(); busy(true);
    var t0 = Date.now();
    $("status").textContent = "Building... 0s";
    var tick = setInterval(function () { $("status").textContent = "Building... " + Math.round((Date.now() - t0) / 1000) + "s (can take a minute)"; }, 1000);
    try {
      var html = await ask(prompt);
      show(html, idea, keepId, keepTitle);
    } catch (e) {
      errEl.textContent = e.name === "AbortError" ? "Stopped." : (e.message || "Something went wrong. Try again.");
      errEl.scrollIntoView({ behavior: "smooth", block: "center" });
    } finally { clearInterval(tick); busy(false); }
  }

  $("build").addEventListener("click", function () {
    var idea = $("idea").value.trim();
    if (!idea) { $("err").textContent = "Describe what you want to build first."; return; }
    run(RULES + "\n\nBuild this: " + idea, $("err"), idea);
  });
  $("stop").addEventListener("click", function () { if (ctrl) ctrl.abort(); });
  $("idea").addEventListener("input", function () { $("err").textContent = ""; });
  document.querySelectorAll(".chip").forEach(function (c) {
    c.addEventListener("click", function () { $("idea").value = c.textContent; $("err").textContent = ""; $("idea").focus(); });
  });

  $("copy").addEventListener("click", function () {
    var idea = $("idea").value.trim();
    if (!idea) { $("err").textContent = "Describe what you want to build first."; return; }
    copyText(RULES + "\n\nBuild this: " + idea, $("copy"), "Copy prompt");
  });
  $("preview").addEventListener("click", function () {
    var code = clean($("paste").value);
    if (!/<!doctype|<html/i.test(code)) { $("err3").textContent = "That doesn't look like an HTML file. Paste the full code Claude gave you."; return; }
    $("err3").textContent = "";
    show(code, $("idea").value.trim());
  });
  $("paste").addEventListener("input", function () { $("err3").textContent = ""; });

  function changeText() {
    var c = $("change").value.trim();
    if (!c) { $("err2").textContent = "Describe the change first."; return null; }
    $("err2").textContent = "";
    return RULES + "\n\nHere is the current project:\n" + cur.html + "\n\nApply this change and return the full updated file: " + c;
  }
  $("update").addEventListener("click", function () {
    var p = changeText();
    if (p) run(p, $("err2"), cur.idea, cur.id, $("title").value.trim());
  });
  $("copychange").addEventListener("click", function () {
    var p = changeText();
    if (p) copyText(p, $("copychange"), "Copy change prompt");
  });
  $("change").addEventListener("input", function () { $("err2").textContent = ""; });
  $("copycode").addEventListener("click", function () { copyText(cur.html, $("copycode"), "Copy code"); });
  $("dl").addEventListener("click", function () {
    download(slug($("title").value) + ".html", cur.html, "text/html");
  });

  $("save").addEventListener("click", function () {
    var title = $("title").value.trim() || guessTitle(cur.idea, cur.html);
    $("title").value = title;
    var now = Date.now(), p = projects.filter(function (x) { return x.id === cur.id; })[0];
    if (p) { p.title = title; p.html = cur.html; p.idea = cur.idea; p.updated = now; }
    else { cur.id = uid(); projects.push({ id: cur.id, title: title, idea: cur.idea, html: cur.html, updated: now }); }
    if (persist()) { $("savemsg").textContent = "Saved as \u201C" + title + "\u201D."; renderSaved(); }
    else { $("savemsg").textContent = "Couldn't save. Your browser may be blocking storage, so download the file instead."; }
  });
  $("title").addEventListener("input", function () { $("savemsg").textContent = ""; });

  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }
  function action(label, fn) {
    var b = el("button", "btn alt small", label);
    b.type = "button"; b.addEventListener("click", fn);
    return b;
  }
  function renderSaved() {
    var box = $("saved");
    box.textContent = "";
    $("exportall").hidden = !projects.length;
    if (!projects.length) { box.appendChild(el("p", "hint", "Nothing saved yet. Build something, give it a title, and press Save project.")); return; }
    projects.slice().sort(function (a, b) { return b.updated - a.updated; }).forEach(function (p) {
      var row = el("div", "proj"), info = el("div", "proj-info");
      info.appendChild(el("strong", null, p.title));
      info.appendChild(el("span", "hint", "Updated " + fmt(p.updated)));
      var acts = el("div", "proj-acts");
      acts.appendChild(action("Open", function () { show(p.html, p.idea, p.id, p.title); }));
      acts.appendChild(action("Rename", function () {
        var t = window.prompt("Project title", p.title);
        if (t && t.trim()) { p.title = t.trim(); p.updated = Date.now(); persist(); renderSaved(); if (cur.id === p.id) $("title").value = p.title; }
      }));
      acts.appendChild(action("Download", function () { download(slug(p.title) + ".html", p.html, "text/html"); }));
      acts.appendChild(action("Delete", function () {
        if (window.confirm("Delete \u201C" + p.title + "\u201D? This can't be undone.")) {
          projects = projects.filter(function (x) { return x.id !== p.id; });
          if (cur.id === p.id) cur.id = null;
          persist(); renderSaved();
        }
      }));
      row.appendChild(info); row.appendChild(acts); box.appendChild(row);
    });
  }
  $("exportall").addEventListener("click", function () {
    download("swell-projects.json", JSON.stringify(projects, null, 2), "application/json");
  });
  renderSaved();
})();
